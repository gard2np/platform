import React, { useState } from 'react';
import { heavenlyStems, earthlyBranches, hiddenStems } from '~/data/stems';
import BranchCard from '~/components/BranchCard';
import Slot from '~/components/Slot';
import StemButton from '~/components/StemButton';
import ResultModal from '~/components/ResultModal';
import { Button } from "~/components/ui/button";
import { CardHeader, CardTitle } from './ui/card';

const getRandomBranch = () => earthlyBranches[Math.floor(Math.random() * earthlyBranches.length)];

const Quiz: React.FC = () => {
  const [branch, setBranch] = useState(getRandomBranch());
  const [selectedSlot, setSelectedSlot] = useState<'initial' | 'middle' | 'final' | null>(null);
  const [answers, setAnswers] = useState<{ initial?: string; middle?: string; final?: string }>({});
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  const correctAnswer = hiddenStems[branch];

  const handleSlotClick = (slot: 'initial' | 'middle' | 'final') => {
    setSelectedSlot(slot);
  };

  const handleStemSelect = (stem: string) => {
    if (selectedSlot) {
      setAnswers((prev) => ({ ...prev, [selectedSlot]: stem }));
      setSelectedSlot(null);
    }
  };

  const handleSubmit = () => {
    setIsCorrect(
      answers.initial === correctAnswer.initial &&
      answers.middle === correctAnswer.middle &&
      answers.final === correctAnswer.final
    );
  };

  return (
    <div className="p-6 flex flex-col items-center">
        <CardHeader>
            <CardTitle className='w-xl mt-4 mb-14 text-2xl font-bold text-center'>지장간 암기 도우미</CardTitle>
        </CardHeader>
      <BranchCard branch={branch} />

      <div className="flex space-x-4 mt-4">
        <Slot label="초기" selectedStem={answers.initial} isSelected={selectedSlot === 'initial'} onSelect={() => handleSlotClick('initial')} />
        {correctAnswer.middle && (
          <Slot label="중기" selectedStem={answers.middle} isSelected={selectedSlot === 'middle'} onSelect={() => handleSlotClick('middle')} />
        )}
        <Slot label="여기" selectedStem={answers.final} isSelected={selectedSlot === 'final'} onSelect={() => handleSlotClick('final')} />
      </div>

      <div className="flex flex-wrap justify-center mt-6">
        {heavenlyStems.map((stem) => (
          <StemButton key={stem} stem={stem} onClick={() => handleStemSelect(stem)} />
        ))}
      </div>

      <Button className="mt-4 bg-blue-500 text-white p-2 rounded-lg" onClick={handleSubmit}>
        제출
      </Button>

      {isCorrect !== null && <ResultModal isCorrect={isCorrect} onClose={() => setIsCorrect(null)} />}
    </div>
  );
};

export default Quiz;
